package com.tagcommander.lib.serverside

import android.content.Context
import com.tagcommander.lib.core.ETCConsentBehaviour
import com.tagcommander.lib.core.TCDebug

/**
 * All the settings of the ServerSide module in one object. Pass it to
 * `TCServerSide(TCServerSideConfiguration(...))`.
 *
 * Only [appContext], [siteID] and [sourceKey] are required; everything else is optional.
 * See "Initialisation" in the ServerSide implementation guide.
 *
 * @param appContext your application's context.
 * @param siteID your site ID, as given by your consulting team.
 * @param sourceKey your Android source key, as given by your consulting team.
 * @param consentBehaviour how the module behaves regarding user consent.
 *   Default: [ETCConsentBehaviour.PB_DEFAULT_BEHAVIOUR]. See "Consent" in the ServerSide
 *   implementation guide.
 * @param gatewayURL your Commanders Act Gateway link, enabling first-party tracking
 *   (e.g. "https://www.mydomain.com/gateway-path"). Leave null to use Commanders Act's default
 *   endpoint. If you also use the Consent module, pass it the same link. See "First-party tracking
 *   (CommandersAct Gateway)" in the ServerSide implementation guide.
 * @param runInBackground set to `true` only if your app needs to keep sending events while in
 *   background (e.g. music playback). See "Background Mode" in the ServerSide implementation guide.
 * @param collectAdvertisingID set to `true` to add the AAID to your events. Only enable this once
 *   the user has accepted the corresponding consent category. See "Getting AAID" in the ServerSide
 *   implementation guide.
 * @param permanentData key/values added to every event. See "Layer 3 — Permanent Data" in the
 *   ServerSide implementation guide.
 * @param debugLevel SDK log level (e.g. `Log.VERBOSE`).
 * @param logNotifications set to `true` to log SDK internal notifications.
 * @param prettyFormatLogs set to `true` to pretty-print logged events.
 * @param blockHits set to `true` to block all outgoing hits (testing only).
 */
data class TCServerSideConfiguration @JvmOverloads constructor(
    val appContext: Context,
    val siteID: Int,
    val sourceKey: String,
    val consentBehaviour: ETCConsentBehaviour = ETCConsentBehaviour.PB_DEFAULT_BEHAVIOUR,
    val gatewayURL: String? = null,
    val runInBackground: Boolean = false,
    val collectAdvertisingID: Boolean = false,
    val permanentData: Map<String, String> = emptyMap(),
    val debugLevel: Int? = null,
    val logNotifications: Boolean? = null,
    val prettyFormatLogs: Boolean? = null,
    val blockHits: Boolean? = null
)

/**
 * Applies optional knob of [configuration] onto [serverSide] via the exact same public
 * methods an integrator would call by hand today — this duplicates no initialisation logic, it
 * only sequences existing calls. `TCServerSide(TCServerSideConfiguration(...))` calls this right
 * after init.
 */
@Suppress("DEPRECATION") // calls the legacy setter this configuration replaces
internal fun applyTCServerSideConfiguration(configuration: TCServerSideConfiguration, serverSide: TCServerSide) { /* compiled code */ }
