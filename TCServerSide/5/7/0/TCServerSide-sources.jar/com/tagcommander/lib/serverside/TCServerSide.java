package com.tagcommander.lib.serverside;

import android.content.Context;

import com.tagcommander.lib.core.ETCConsentBehaviour;
import com.tagcommander.lib.serverside.events.base.TCEvent;

import androidx.annotation.NonNull;

@SuppressWarnings("unused")
public class TCServerSide
{
    /**
     * Creates a new ServerSide instance with the default consent behaviour ({@link ETCConsentBehaviour#PB_DEFAULT_BEHAVIOUR})
     * and the default collect endpoint.
     *
     * @param siteID      identifies your web platform setup, as given by your consulting team.
     * @param sourceKey   identifies this Android source within your configuration, as given by your consulting team.
     * @param appContext  your application's context.
     * @deprecated Use {@link #TCServerSide(TCServerSideConfiguration)} with {@link TCServerSideConfiguration#TCServerSideConfiguration(Context, int, String) TCServerSideConfiguration(appContext, siteID, sourceKey)} instead.
     */
    @Deprecated
    public TCServerSide(int siteID, String sourceKey, Context appContext)
    { /* compiled code */ }

    /**
     * Creates a new ServerSide instance with the default collect endpoint.
     *
     * @param siteID       identifies your web platform setup, as given by your consulting team.
     * @param sourceKey    identifies this Android source within your configuration, as given by your consulting team.
     * @param appContext   your application's context.
     * @param defaultState the behaviour to adopt while waiting for user consent: {@link ETCConsentBehaviour#PB_DEFAULT_BEHAVIOUR}
     *                     (wait for consent if the Consent module is present, otherwise enable immediately),
     *                     {@link ETCConsentBehaviour#PB_ALWAYS_ENABLED} (always send data, ignoring consent), or
     *                     {@link ETCConsentBehaviour#PB_DISABLED_BY_DEFAULT} (stay disabled until consent is given).
     * @deprecated Use {@link #TCServerSide(TCServerSideConfiguration)} and set {@link TCServerSideConfiguration#getConsentBehaviour() consentBehaviour} instead.
     */
    @Deprecated
    public TCServerSide(int siteID, String sourceKey, Context appContext, ETCConsentBehaviour defaultState)
    { /* compiled code */ }

    /**
     * Creates a new ServerSide instance with the default consent behaviour ({@link ETCConsentBehaviour#PB_DEFAULT_BEHAVIOUR})
     * and first-party tracking through a Commanders Act Gateway.
     *
     * @param siteID     identifies your web platform setup, as given by your consulting team.
     * @param sourceKey  identifies this Android source within your configuration, as given by your consulting team.
     * @param appContext your application's context.
     * @param gatewayURL your Commanders Act Gateway link, enabling first-party tracking
     *                   (e.g. "https://www.mydomain.com/gateway-path"), or null for Commanders Act's default
     *                   collect endpoint.
     * @deprecated Use {@link #TCServerSide(TCServerSideConfiguration)} and set {@link TCServerSideConfiguration#getGatewayURL() gatewayURL} instead.
     */
    @Deprecated
    public TCServerSide(int siteID, String sourceKey, Context appContext, String gatewayURL)
    { /* compiled code */ }

    /**
     * Creates a new ServerSide instance with a custom consent behaviour and first-party tracking through a
     * Commanders Act Gateway.
     *
     * @param siteID       identifies your web platform setup, as given by your consulting team.
     * @param sourceKey    identifies this Android source within your configuration, as given by your consulting team.
     * @param appContext   your application's context.
     * @param defaultState the behaviour to adopt while waiting for user consent: {@link ETCConsentBehaviour#PB_DEFAULT_BEHAVIOUR}
     *                     (wait for consent if the Consent module is present, otherwise enable immediately),
     *                     {@link ETCConsentBehaviour#PB_ALWAYS_ENABLED} (always send data, ignoring consent), or
     *                     {@link ETCConsentBehaviour#PB_DISABLED_BY_DEFAULT} (stay disabled until consent is given).
     * @param gatewayURL   your Commanders Act Gateway link, enabling first-party tracking
     *                     (e.g. "https://www.mydomain.com/gateway-path"), or null for Commanders Act's default
     *                     collect endpoint.
     * @deprecated Use {@link #TCServerSide(TCServerSideConfiguration)} and set {@link TCServerSideConfiguration#getConsentBehaviour() consentBehaviour} and {@link TCServerSideConfiguration#getGatewayURL() gatewayURL} instead.
     */
    @Deprecated
    public TCServerSide(int siteID, String sourceKey, Context appContext, ETCConsentBehaviour defaultState, String gatewayURL)
    { /* compiled code */ }

    /**
     * Creates a new ServerSide instance from a {@link TCServerSideConfiguration}: the single-parameter
     * equivalent of the constructors above. Only {@code appContext}, {@code siteID} and {@code sourceKey} are
     * required on the configuration; every other setting (consent behaviour, first-party tracking, background
     * mode, advertising ID, permanent data, TCDebug) is optional and applied right after init, via the exact
     * same public methods you'd otherwise call by hand.
     *
     * @param configuration the grouped ServerSide configuration; see {@link TCServerSideConfiguration}.
     */
    public TCServerSide(@NonNull TCServerSideConfiguration configuration)
    { /* compiled code */ }

    /**
     * Sends an event to Commanders Act. The event is completed with the user, device, app and lifecycle
     * information and with your permanent data (see {@link #addPermanentData(String, String)}), then queued
     * and sent as soon as possible.
     * <p>While waiting for consent the event is kept in the queue and sent once consent is given (or
     * dropped if consent is refused). When ServerSide is disabled, the event is ignored.
     *
     * @param event the event to send, e.g. a {@code TCPageViewEvent} or {@code TCPurchaseEvent}.
     */
    public void execute(@NonNull TCEvent event)
    { /* compiled code */ }

    /**
     * This method should be called only by advanced users that need the SDK to continue working while the application
     * is in background.
     * @deprecated Use {@link #TCServerSide(TCServerSideConfiguration)} and set {@link TCServerSideConfiguration#getRunInBackground() runInBackground} instead.
     */
    @Deprecated
    public void enableRunningInBackground()
    { /* compiled code */ }

    /**
     * Adds a key/value pair to every event sent by this instance, until it is removed with
     * {@link #removePermanentData(String)}. On a key collision, the permanent value overrides a value
     * added to the event with {@code addAdditionalProperty}, but not the event's own fields (event name,
     * page name, page type and typed fields such as revenue), which are kept when set.
     * <p>To set permanent data at init, use {@link TCServerSideConfiguration#getPermanentData() permanentData};
     * call this method to add values only known later, e.g. after login.
     *
     * @param key   the property name.
     * @param value the property value.
     */
    @SuppressWarnings("unused")
    public void addPermanentData(String key, String value)
    { /* compiled code */ }

    /**
     * Returns a permanent data value previously added with {@link #addPermanentData(String, String)}.
     *
     * @param key the property name.
     * @return the value, or {@code null} if the key is not set.
     */
    @SuppressWarnings("unused")
    public String getPermanentData(String key)
    { /* compiled code */ }

    /**
     * Stops adding a permanent data key to the following events.
     *
     * @param key the property name.
     * @return the removed value, or {@code null} if the key was not set.
     */
    @SuppressWarnings("unused")
    public String removePermanentData(String key)
    { /* compiled code */ }

    /**
     * Stops sending events: following {@link #execute(TCEvent)} calls are ignored until
     * {@link #enableServerSide()} is called. Does nothing with {@link ETCConsentBehaviour#PB_ALWAYS_ENABLED}.
     * <p>When the Consent module is linked, it already enables/disables ServerSide from the user's consent.
     */
    public void disableServerSide()
    { /* compiled code */ }

    /**
     * Starts sending events again, including the ones queued while waiting for consent.
     * <p>When the Consent module is linked, it already enables/disables ServerSide from the user's consent.
     */
    public void enableServerSide()
    { /* compiled code */ }

    /**
     * Adds the Android Advertising ID (AAID) and the ad-tracking-enabled flag to your events. Only call it once
     * the user has accepted the corresponding consent category. The AAID is not added when the user limited
     * ad tracking. See "Getting AAID" in the ServerSide implementation guide.
     * <p>If consent is already known at init, set {@link TCServerSideConfiguration#getCollectAdvertisingID() collectAdvertisingID}
     * instead; call this method when the user accepts later.
     */
    public void addAdvertisingID()
    { /* compiled code */ }
}
