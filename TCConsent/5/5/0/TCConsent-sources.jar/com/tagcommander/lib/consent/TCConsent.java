package com.tagcommander.lib.consent;

import android.content.Context;

import java.util.Map;

import androidx.annotation.NonNull;

public class TCConsent
{
    /**
     * Version of the consent sent with every consent hit.
     * <p>With the Privacy Center or Banner, a value set on this field is overwritten by your
     * {@code privacy.json} version at every update.
     * @deprecated Set {@link TCConsentConfiguration#getConsentVersion() consentVersion} in
     * {@link #initialize(TCConsentConfiguration)} instead: that value is kept, even with the Privacy Center.
     */
    @Deprecated
    public String consentVersion = "1";

    public int maxVendorID = 0;

    /**
     * IAB only: also generate the publisher TC string.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getGeneratePublisherTC() generatePublisherTC} instead.
     */
    @Deprecated
    public Boolean generatePublisherTC = false;

    /**
     * Disables the Privacy Center's back button, forcing the user to make a choice.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getDeactivateBackButton() deactivateBackButton} instead.
     */
    @Deprecated
    public boolean deactivateBackButton = false;

    /**
     * Language code currently used for the Privacy Center/Banner texts and the TC string, or {@code null}
     * for the default. Read-only in practice: assigning it does not reload the translations.
     * @deprecated Set the language with {@link #initialize(TCConsentConfiguration)} ({@link TCConsentConfiguration#getLanguage() language})
     *             at init, or {@link #setLanguage(String)} after init.
     */
    @Deprecated
    public String consentLanguage = null;

    /**
     * Default on/off state of the Privacy Center switches.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getSwitchDefaultState() switchDefaultState} instead.
     */
    @Deprecated
    public Boolean switchDefaultState = false;

    /**
     * IAB only: TCF policy version written into the TC string.
     * <p>Set automatically from the IAB {@code vendor-list.json} (bundled-UI init only); you should not change it.
     */
    public int tcfPolicyVersion = 5;

    /**
     * Flags every privacy hit with {@code "do_not_track": true}, asking Commanders Act to exclude it from
     * privacy statistics. Hits, including consent-save hits, are still sent.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getDoNotTrack() doNotTrack} at init,
     *             or {@link #setDoNotTrack(boolean)} after init.
     */
    @Deprecated
    public boolean do_not_track = false;

    /**
     * Returns the TCConsent singleton.
     *
     * @return the single TCConsent instance.
     */
    public static TCConsent getInstance()
    { /* compiled code */ }

    /**
     * Sets how long a saved consent stays valid before the user is asked again. Must be called before init.
     * Defaults to the value in your {@code privacy.json}, or 6 months.
     *
     * @param months validity duration, in months.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getConsentDurationInMonths() consentDurationInMonths} instead.
     */
    @Deprecated
    public void setConsentDuration(float months)
    { /* compiled code */ }

    /**
     * NON-IAB only: initializes the TCConsent module WITHOUT our Privacy Center / Banner, for apps that build
     * their own consent UI.
     * <p>On this path {@link #acceptAllConsent()}, {@link #refuseAllConsent()},
     * {@link #getNumberOfIABVendors()}, {@link #setLanguage}, the Privacy Center and the Banner are
     * not available.
     *
     * @param siteID      the client's site ID.
     * @param privacyID   the ID corresponding to the chosen privacy.
     * @param appContext  the context of the application.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} with {@code useBundledUI = false} instead.
     */
    @Deprecated
    @SuppressWarnings("unused")
    public void initWithCustomPCM(int siteID, int privacyID, Context appContext)
    { /* compiled code */ }

    /**
     * initialize the TCConsent module with our Privacy Center & sets the site ID that will be used to query the API.
     *
     * @param siteID      the client's site ID.
     * @param privacyID   the ID corresponding to the chosen privacy.
     * @param appContext  the context of the application.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} with {@code useBundledUI = true} instead.
     */
    @Deprecated
    @SuppressWarnings("unused")
    public void setSiteIDPrivacyIDAppContext(int siteID, int privacyID, Context appContext)
    { /* compiled code */ }

    /**
     * Initializes the consent module from a single {@link TCConsentConfiguration}, grouping the
     * setup currently spread across {@link #setSiteIDPrivacyIDAppContext}/{@link #initWithCustomPCM}
     * and the setter calls that have to surround them into one call. Also applies the configuration's
     * global {@code TCDebug} settings.
     * <p>Call it once, e.g. in {@code Application.onCreate}: once the module is initialized, further
     * calls log an error and change nothing. To change settings after init, use
     * {@link #setLanguage(String)}, {@link #setDoNotTrack(boolean)} and
     * {@link #registerCallback(TCPrivacyCallbacks)}. {@code useBundledUI = false} is non-IAB only.
     *
     * @param configuration groups every TCConsent configuration knob; see {@link TCConsentConfiguration}.
     */
    public void initialize(@NonNull TCConsentConfiguration configuration)
    { /* compiled code */ }

    /**
     * Excludes, or includes again, the user from privacy statistics after init, e.g. when they opt out
     * in your app's settings. Set the initial value with
     * {@link TCConsentConfiguration#getDoNotTrack() doNotTrack}.
     * <p>With {@code true}, every following privacy hit is flagged with {@code "do_not_track": true} so
     * it is left out of the statistics.
     *
     * Hits, including consent-save hits, are still sent.
     *
     * <p><b>The module must already be initialized</b> with {@link #initialize(TCConsentConfiguration)};
     * otherwise this logs an error and changes nothing.
     *
     * @param doNotTrack {@code true} to exclude the user from privacy statistics.
     */
    public void setDoNotTrack(boolean doNotTrack)
    { /* compiled code */ }

    /**
     * Routes the IAB / GVL files, {@code privacy.json}, {@code TCIABPublisherRestrictions.json} and the
     * consent hits through your Commanders Act Gateway (first-party privacy), e.g.
     * {@code "https://www.mydomain.com/gateway-path"}. Null or blank keeps Commanders Act's default endpoints.
     * <p><b>Call it before init</b> ({@link #setSiteIDPrivacyIDAppContext}/{@link #initWithCustomPCM}):
     * the file URLs are set during init. Once the module is initialized, this logs an error and
     * changes nothing.
     *
     * @param gatewayURL your Gateway link, or null for the default endpoints.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getGatewayURL() gatewayURL} instead.
     */
    @Deprecated
    public void setGatewayURL(String gatewayURL)
    { /* compiled code */ }

    /**
     * IAB only: applies your own publisher restrictions. Must be called after init.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getUseCustomPublisherRestrictions() useCustomPublisherRestrictions} instead.
     */
    @Deprecated
    @SuppressWarnings("unused")
    public void useCustomPublisherRestrictions()
    { /* compiled code */ }

    /**
     *  NON-IAB only, The entry point for a Save consent action.<br>
     * to call when your user answered about the consent from your <b>PopUp with a Save action.</b><br>
     * This will also send a hit to save the consent in our databases
     * <p>
     * If the consent map is null, we take this as a full refusal.
     * <p>When TCIAB is linked, logs an error and does nothing: IAB consent must come from a validated UI.
     *
     * @param consent the consent categories opted-in/out
     */
    public void saveConsentFromPopUp(Map<String, String> consent)
    { /* compiled code */ }

    /**
     * NON-IAB only, The entry point for a Save consent action.<br>
     * to call when your user answered about the consent from the <b>Privacy Center with a Save action</b>.<br>
     * This will also send a hit to save the consent in our databases
     * <p>
     * If the consent map is null, we take this as a full refusal.
     * <p>When TCIAB is linked, logs an error and does nothing: IAB consent must come from a validated UI.
     *
     * @param consent the consent categories opted-in/out
     */
    public void saveConsent(Map<String, String> consent)
    { /* compiled code */ }

    /**
     * NON-IAB only,  The entry point to call when you user answered about the consent.<br>
     * This will also send a hit to save the consent in our databases
     * <p>
     * If the consent map is null, we take this as a full refusal.
     * <p>When TCIAB is linked, logs an error and does nothing: IAB consent must come from a validated UI.
     *
     * @param consent the consent categories opted-in/out
     * @param source the source screen of the consent, a ETCConsentSource enum.
     * @param action the action of the user for the consent, a ETCConsentAction enum.
     */
    public void saveConsentFromConsentSourceWithPrivacyAction(Map<String, String> consent, ETCConsentSource source, ETCConsentAction action)
    { /* compiled code */ }

    /**
     * Sends a statistic hit telling that the user has seen the consent form, before they accept or refuse.
     *
     * @deprecated Use {@link #statViewPrivacyCenter()} instead, which sends the same hit.
     */
    @Deprecated
    public void viewConsent()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when the user opens the vendor screen directly from your banner or first-layer.
     * Sends both the {@link #statViewPrivacyCenter()} and {@link #statShowVendorScreen()} hits.
     * <p>Our Privacy Center and Banner never call this: call it from your own UI. Does nothing if the module is not initialized.
     */
    public void statEnterPCToVendorScreen()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when your vendor screen is displayed.
     * <p>Only needed if you built your own consent UI: our Privacy Center and Banner already call it internally. Does nothing if the module is not initialized.
     */
    public void statShowVendorScreen()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when the user opens your privacy policy from your banner.
     * <p>Only needed if you built your own consent UI: our Privacy Center and Banner already call it internally. Does nothing if the module is not initialized.
     */
    public void statViewPrivacyPoliciesFromBanner()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when the user opens your privacy policy from your Privacy Center.
     * <p>Our Privacy Center and Banner never call this: call it from your own UI. Does nothing if the module is not initialized.
     */
    public void statViewPrivacyPoliciesFromPrivacyCenter()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when your Privacy Center is displayed.
     * <p>Only needed if you built your own consent UI: our Privacy Center and Banner already call it internally. Does nothing if the module is not initialized.
     */
    public void statViewPrivacyCenter()
    { /* compiled code */ }

    /**
     * Privacy statistics: call when your custom banner is displayed.
     * <p>Only needed if you built your own consent UI: our Privacy Center and Banner already call it internally. Does nothing if the module is not initialized.
     */
    public void statViewBanner()
    { /* compiled code */ }

    /**
     * Returns all the saved consent as a JSON string, e.g. to forward it to a WebView's local storage.
     * You still need JavaScript code inside the web container to consume it.
     *
     * @return the saved consent as a JSON string, or {@code "{}"} if no consent was saved.
     */
    public String getConsentAsJson()
    { /* compiled code */ }

    /**
     * Deletes the consent saved on the device, every time it is called: also clears the IAB TC string
     * and AC string, and stops ServerSide until consent is given again. It does not show the Privacy
     * Center: it only makes {@link TCConsentAPI#shouldDisplayPrivacyCenter(Context)} return
     * {@code true} again, and showing it is up to your app. Requires init. Resetting per app version
     * has to be handled by your app.
     * <p>The same reset also runs automatically when a newly downloaded {@code privacy.json} has
     * {@code resetSave} enabled (set from the Commanders Act platform; contact your consultant).
     */
    public void resetSavedConsent()
    { /* compiled code */ }

    /**
     * Registers your {@link TCPrivacyCallbacks}, notified when consent is given, loaded or outdated at
     * startup, and when your {@code privacy.json} changes. Only one callback is kept: a new call
     * replaces the previous one.
     * <p>To receive the startup calls, set your callback at init with
     * {@link TCConsentConfiguration#getCallback() callback}; call this method after init to replace it.
     *
     * @param callback your callback object.
     */
    public void registerCallback(TCPrivacyCallbacks callback)
    { /* compiled code */ }

    /**
     * Sets the language of the Privacy Center and Banner texts (and, with IAB, the TC string consent
     * language and the IAB purposes translation). Set the initial language with
     * {@link TCConsentConfiguration#getLanguage() language}; call this method after init to switch
     * language while the app runs. The new texts are used the next time the Privacy Center or Banner
     * is shown.
     * <p>The language must have its own translations in your {@code privacy.json}
     * ({@code texts_xx}, {@code categories_xx}, {@code vendors_xx}); otherwise the current texts are kept.
     * <p><b>The module must already be initialized</b> with our Privacy Center
     * ({@code useBundledUI = true}); otherwise this logs an error and changes nothing.
     *
     * @param languageCode language code, e.g. {@code "fr"}.
     */
    public void setLanguage(String languageCode)
    { /* compiled code */ }

    /**
     * To call <b>from PopUp</b> when user opt for an <b>acceptAll action</b>.<br>
     * Accepts and save consent for all the current used categories<br>
     * <b>Can only be used if you are using our Privacy Center.</b>
     * <p>Requires a bundled-UI init ({@code useBundledUI = true} / {@link #setSiteIDPrivacyIDAppContext}); otherwise logs an error and does nothing. Works with and without
     * IAB; with IAB, this and {@link #refuseAllConsent()} are the only programmatic consent calls.
     */
    public void acceptAllConsent()
    { /* compiled code */ }

    /**
     * To call <b>from PopUp</b> when user opt for an <b>RefuseAll action</b>.<br>
     * Refuses and save consent for all the current used categories<br>
     * <b>Can only be used if you are using our Privacy Center.</b>
     * <p>Requires a bundled-UI init ({@code useBundledUI = true} / {@link #setSiteIDPrivacyIDAppContext}); otherwise logs an error and does nothing. Works with and without
     * IAB; with IAB, this and {@link #acceptAllConsent()} are the only programmatic consent calls.
     */
    public void refuseAllConsent()
    { /* compiled code */ }

    /**
     * IAB only: returns the number of IAB vendors shown in the first layer.
     * <p>Requires a bundled-UI init ({@code useBundledUI = true} / {@link #setSiteIDPrivacyIDAppContext}); throws a {@code NullPointerException} after {@link #initWithCustomPCM}.
     *
     * @return the number of IAB vendors, {@code 0} if TCIAB is not linked, or {@code null} if the module
     *         is not initialized.
     */
    public Integer getNumberOfIABVendors()
    { /* compiled code */ }

    /**
     * IAB only: enables Google's Additional Consent (AC) String. Must be called before init.
     *
     * @param useACString {@code true} to enable the AC String.
     * @deprecated Use {@link #initialize(TCConsentConfiguration)} and set {@link TCConsentConfiguration#getUseAcString() useAcString} instead.
     */
    @Deprecated
    public void useAcString(boolean useACString)
    { /* compiled code */ }

    public boolean isACStringEnabled()
    { /* compiled code */ }

    /**
     * Whether a newly downloaded {@code privacy.json} is applied immediately ({@code true}, default)
     * callbacks still fire immediately; only re-parsing is deferred.
     */
    public void shouldForceJsonUpdate(boolean value)
    { /* compiled code */ }
}