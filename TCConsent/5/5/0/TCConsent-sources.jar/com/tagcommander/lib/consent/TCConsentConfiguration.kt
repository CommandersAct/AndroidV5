package com.tagcommander.lib.consent

import android.content.Context
import com.tagcommander.lib.core.TCDebug

/**
 * Groups every knob that today is spread across `TCConsent`'s two init entry points
 * ([TCConsent.setSiteIDPrivacyIDAppContext]/[TCConsent.initWithCustomPCM]) and a handful of
 * setter calls that have to surround them ([TCConsent.registerCallback], [TCConsent.useAcString],
 * [TCConsent.setConsentDuration], [TCConsent.setLanguage], TCDebug, ...) into a single object.
 *
 * [appContext], [siteID], [privacyID] and [useBundledUI] are required — everything else keeps the
 * same default behaviour TCConsent already has today. Pass this to
 * `TCConsent.getInstance().initialize(TCConsentConfiguration(...))`.
 *
 * @param appContext your application's context.
 * @param siteID your site ID.
 * @param privacyID your privacy ID corresponding to the chosen privacy on CommandersAct plateforme.
 * @param useBundledUI required.
 *   `true`: use Commanders Act's Privacy Center and Banner (needs `privacy.json`). equivalent to legacy init methode : setSiteIDPrivacyIDAppContext
 *   `false`: build your own consent UI. equivalent to legacy init methide : initWithCustomPCM
 * @param callback your [TCPrivacyCallbacks] object, notified when consent is given or loaded at
 *   startup. See "Reacting to consent" in the Consent implementation guide.
 * @param useAcString set to `true` if you use IAB and want to enable Google's AC String.
 *   See the TCIAB documentation.
 * @param consentDurationInMonths how long a saved consent stays valid before the user is asked
 *   again. Defaults to the value in your `privacy.json`, or 6 months.
 *   See "Consent validity duration" in the Consent implementation guide.
 * @param language language code of the Privacy Center and Banner texts. Only used when
 *   [useBundledUI] is `true`.
 * @param switchDefaultState default on/off state of the Privacy Center switches.
 * @param deactivateBackButton set to `true` to disable the Privacy Center's back button and force
 *   the user to make a choice.
 * @param consentVersion your consent version, sent with every consent hit. Required in practice
 *   when building your own consent UI ([useBundledUI] set to `false`). With [useBundledUI] `true`,
 *   leave it null to use the version of your `privacy.json`; if you set it, it overrides that
 *   version, even after `privacy.json` updates. Keeping it in line with what your users are shown
 *   is then your responsibility.
 * @param doNotTrack set to `true` to stop sending privacy statistics.
 *   See "Privacy statistics" in the Consent implementation guide.
 * @param generatePublisherTC IAB only: set to `true` to also generate the publisher TC string.
 *   See the TCIAB documentation.
 * @param useCustomPublisherRestrictions IAB only: set to `true` to apply your own publisher
 *   restrictions. See the TCIAB documentation.
 * @param gatewayURL your Commanders Act Gateway link, enabling first-party privacy
 *   (e.g. "https://www.mydomain.com/gateway-path"). Leave null to use Commanders Act's default
 *   endpoints. See "First-party privacy (CommandersAct Gateway)" in the Consent implementation guide.
 * @param debugLevel SDK log level (e.g. `Log.VERBOSE`).
 * @param logNotifications set to `true` to log SDK internal notifications.
 * @param prettyFormatLogs set to `true` to pretty-print logged events.
 * @param blockHits set to `true` to block all outgoing hits (testing only).
 */
data class TCConsentConfiguration @JvmOverloads constructor(
    val appContext: Context,
    val siteID: Int,
    val privacyID: Int,
    val useBundledUI: Boolean,
    val callback: TCPrivacyCallbacks? = null,
    val useAcString: Boolean = false,
    val consentDurationInMonths: Float? = null,
    val language: String? = null,
    val switchDefaultState: Boolean = false,
    val deactivateBackButton: Boolean = false,
    val consentVersion: String? = null,
    val doNotTrack: Boolean = false,
    val generatePublisherTC: Boolean = false,
    val useCustomPublisherRestrictions: Boolean = false,
    val gatewayURL: String? = null,
    val debugLevel: Int? = null,
    val logNotifications: Boolean? = null,
    val prettyFormatLogs: Boolean? = null,
    val blockHits: Boolean? = null
)

/**
 * Applies every knob of [configuration] onto [consent] via the exact same public methods/fields an
 * integrator would call by hand today — this duplicates no initialisation logic, it only sequences
 * existing calls in the order TCConsent's internals require.
 * `TCConsent.initialize(TCConsentConfiguration(...))` calls this.
 */
@Suppress("DEPRECATION") // calls the legacy setters this configuration replaces
internal fun applyTCConsentConfiguration(configuration: TCConsentConfiguration, consent: TCConsent) { /* compiled code */ }
